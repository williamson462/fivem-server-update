fx_version 'adamant'

game 'gta5'

description 'cron'

version '1.0.1'

server_script 'server/main.lua'
